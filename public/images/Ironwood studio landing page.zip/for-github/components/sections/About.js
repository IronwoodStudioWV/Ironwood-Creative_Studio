import styles from './About.module.css';

export default function About() {
  return (
    <section id="about" className={styles.about}>
      <div className={styles.container}>
        <h2>About Ironwood</h2>
        <p>
          Ironwood Creative Studio is an Appalachian-rooted creative studio specializing in
          branding, web design, and visual identity systems, and creative strategy. We help
          businesses build authentic brands through thoughtful design, craftsmanship, and
          purpose-driven storytelling.
        </p>
        <div className={styles.values}>
          <span>Strong</span>
          <span>Honest</span>
          <span>Creative</span>
          <span>Hands-On</span>
          <span>Reliable</span>
          <span>Appalachian-Rooted</span>
        </div>
      </div>
    </section>
  );
}
