import styles from './FeaturedProjects.module.css';

export default function FeaturedProjects() {
  return (
    <section className={styles.projects}>
      <div className={styles.container}>
        <h2>Featured Projects</h2>
        <div className={styles.card}>
          <h3>Appalachian Timber Co.</h3>
          <p>A branding project inspired by Appalachian craftsmanship, heritage, and enduring quality.</p>
          <span>More projects coming soon</span>
        </div>
      </div>
    </section>
  );
}
