import styles from './Services.module.css';

const services = [
  'Brand Identity Design',
  'Logo Development',
  'Web Design',
  'Marketing Materials',
  'Creative Strategy',
];

export default function Services() {
  return (
    <section id="services" className={styles.services}>
      <h2>Services</h2>
      <div className={styles.grid}>
        {services.map((title) => (
          <div className={styles.card} key={title}>
            <h3>{title}</h3>
          </div>
        ))}
      </div>
    </section>
  );
}
