import styles from './Contact.module.css';

export default function Contact() {
  return (
    <section id="contact" className={styles.contact}>
      <h2>Let&apos;s Talk</h2>
      <p>Have a project in mind? Reach out.</p>
      <div className={styles.details}>
        <a href="mailto:joshua.mitchell11@snhu.edu">joshua.mitchell11@snhu.edu</a>
        <span>West Virginia, USA</span>
      </div>
    </section>
  );
}
