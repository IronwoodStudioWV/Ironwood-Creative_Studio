# How to add this to your repo

Your site is a Next.js app (React components + CSS modules), not plain HTML — so the
`.dc.html` file can't be dropped in directly. These files match your existing code style
and go straight into your project:

1. Copy the `components/sections/` files here into your repo's `components/sections/` folder
   (About.js, About.module.css, Services.js, Services.module.css, FeaturedProjects.js,
   FeaturedProjects.module.css, Contact.js, Contact.module.css).
2. Replace your `app/page.js` with the one here — it just adds the four new sections
   after your existing Header and Hero.
3. Commit and push (or open a PR) as usual: `git add . && git commit -m "Add About, Services, Featured Projects, Contact sections" && git push`.

Nothing in your existing Header or Hero changes.
